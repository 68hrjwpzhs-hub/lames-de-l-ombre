#!/bin/sh
cd "$(dirname "$0")"
{ cat src/head.html; echo "<script>"; cat src/core.js src/figure.js src/figure_styles.js src/cloth.js src/scenery.js src/venues.js src/paint.js src/depth.js src/perf.js src/pwa.js src/replay.js src/bilan.js src/sound.js src/music.js src/progress.js src/run.js src/story.js src/cine.js src/codex.js src/story2.js src/finisher.js src/manuscrit.js src/ambiance.js src/heroes.js src/game.js src/ai.js src/training.js src/venues2.js src/story3.js src/offhand.js src/defi.js src/ecole.js src/controls.js src/lang_en.js src/i18n.js src/v2.js src/input.js; echo "</script>"; } > index.html
node -e "const s=require('fs').readFileSync('index.html','utf8');const js=s.slice(s.indexOf('<script>')+8,s.lastIndexOf('</script>'));try{new Function(js);console.log('syntax ok',js.split('\n').length,'lines')}catch(e){console.log('ERR',e.message)}"
echo "2D ok (rendu cinéma seul ; le rendu 3D est retiré, sources archivées dans src3d/)"

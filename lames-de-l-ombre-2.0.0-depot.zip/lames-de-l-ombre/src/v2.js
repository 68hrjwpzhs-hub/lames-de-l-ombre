// =============================== 2.0 : branchement des nouveautés (appelé par G.init, après le menu) ===============================
const V2 = {
  screens: ['defi', 'ecole'],
  panel(k) { return document.querySelector(`#menu .mpanel[data-k="${k}"]`); },
  mods() { return [typeof Offhand !== 'undefined' && Offhand, typeof Defi !== 'undefined' && Defi, typeof Ecole !== 'undefined' && Ecole, typeof Controls !== 'undefined' && Controls, typeof A11y !== 'undefined' && A11y, typeof I18N !== 'undefined' && I18N].filter(Boolean); },
  init() {
    // écrans ajoutés : masqués comme les autres par G.show
    const sh = G.show; G.show = function (id) { const r = sh.apply(this, arguments); for (const s of V2.screens) { const el = $(s); if (el) el.hidden = s !== id; } if (id === 'menu' && typeof Defi !== 'undefined') Defi.badge(); return r; };
    for (const M of this.mods()) { try { M.init(); } catch (e) { console.error('V2', e); } }
    try { Offhand.menu(this.panel('salle')); } catch (e) { console.error('V2 menu', e); }
  },
};
